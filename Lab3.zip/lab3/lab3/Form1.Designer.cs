﻿namespace lab3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumber = new TextBox();
            btnSumDigits = new Button();
            btnCountEven = new Button();
            lblResult = new Label();
            result = new Label();
            res = new Label();
            SuspendLayout();
            // 
            // txtNumber
            // 
            txtNumber.ForeColor = SystemColors.ActiveCaptionText;
            txtNumber.Location = new Point(33, 17);
            txtNumber.Name = "txtNumber";
            txtNumber.Size = new Size(167, 27);
            txtNumber.TabIndex = 0;
            // 
            // btnSumDigits
            // 
            btnSumDigits.BackColor = SystemColors.ControlLight;
            btnSumDigits.Location = new Point(33, 63);
            btnSumDigits.Name = "btnSumDigits";
            btnSumDigits.Size = new Size(167, 29);
            btnSumDigits.TabIndex = 1;
            btnSumDigits.Text = "The Sum Of Digits";
            btnSumDigits.UseVisualStyleBackColor = false;
            btnSumDigits.Click += btnSumDigits_Click;
            // 
            // btnCountEven
            // 
            btnCountEven.BackColor = Color.CornflowerBlue;
            btnCountEven.Location = new Point(33, 107);
            btnCountEven.Name = "btnCountEven";
            btnCountEven.Size = new Size(167, 29);
            btnCountEven.TabIndex = 2;
            btnCountEven.Text = "Count Even Digits";
            btnCountEven.UseVisualStyleBackColor = false;
            btnCountEven.Click += btnCountEven_Click;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(246, 23);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(56, 20);
            lblResult.TabIndex = 3;
            lblResult.Text = "Result: ";
            lblResult.Click += lblResult_Click;
            // 
            // result
            // 
            result.AutoSize = true;
            result.Location = new Point(308, 23);
            result.Name = "result";
            result.Size = new Size(0, 20);
            result.TabIndex = 4;
            // 
            // res
            // 
            res.AutoSize = true;
            res.Location = new Point(308, 23);
            res.Name = "res";
            res.Size = new Size(12, 20);
            res.TabIndex = 5;
            res.Text = ".";
            res.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(res);
            Controls.Add(result);
            Controls.Add(lblResult);
            Controls.Add(btnCountEven);
            Controls.Add(btnSumDigits);
            Controls.Add(txtNumber);
            Cursor = Cursors.PanWest;
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumber;
        private Button btnSumDigits;
        private Button btnCountEven;
        private Label lblResult;
        private Label result;
        private Label res;
    }
}
