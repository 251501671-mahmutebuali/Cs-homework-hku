namespace lab3
{
    public partial class Form1 : Form
    {
        int calculateSum(int x)
        {
            int sum = 0;

            while (x > 0)
            {
                sum = sum + x % 10;
                x = x / 10;
            }

            return sum;
        }

        int countEven(int x)
        {
            int even = 0;

            if (x == 0)
            {
                return 1;
            }

            while (x > 0)
            {
                int digit = x % 10;

                if (digit % 2 == 0)
                {
                    even += 1;
                }

                x = x / 10;
            }

            return even;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void lblResult_Click(object sender, EventArgs e)
        {

        }

        private void btnSumDigits_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(txtNumber.Text);

            if (x >= 0)
            {
                int result = calculateSum(x);
                res.Text = result.ToString();
            }
            else
            {
                res.Text = "Invalid Number";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCountEven_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(txtNumber.Text);

            if (x >= 0)
            {
                int result = countEven(x);
                res.Text = result.ToString();
            }
            else
            {
                res.Text = "Invalid Number";
            }
        }
    }
}
