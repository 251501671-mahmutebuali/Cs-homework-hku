
namespace calc2
{
    public partial class Form1 : Form
    {
        bool isPassing(int score)
        {
            if (score >= 50)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        string GetLetterGrade(int score)
        {
            if (score >= 90)
            {
                return "A";
            }
            else if (score >= 80)
            {
                return "B";
            }
            else if (score >= 70)
            {
                return "C";
            }
            else if (score >= 60)
            {
                return "D";
            }
            else
            {
                return "F";
            }
        }

        int CalculateNeededScore(int score)
        {
            return 100 - score;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textScore_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnCheckPass_Click(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(textScore.Text);

                if (x < 0 || x > 100)
                {
                    lblResult.Text = "Invalid Score";
                }
                else if (isPassing(x))
                {
                    lblResult.Text = "Pass";
                }
                else
                {
                    lblResult.Text = "Fail";
                }
            }
            catch
            {
                lblResult.Text = "Enter a valid number";
            }
        }

        private void btnLetterGrade_Click(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(textScore.Text);

                if (x < 0 || x > 100)
                {
                    lblResult.Text = "Invalid Score";
                }
                else
                {
                    lblResult.Text = "Grade: " + GetLetterGrade(x);
                }
            }
            catch
            {
                lblResult.Text = "Enter a valid number";
            }
        }

        private void btnAverage_Click_1(object sender, EventArgs e)
        {
            try
            {
                int x = Convert.ToInt32(textScore.Text);

                if (x < 0 || x > 100)
                {
                    lblResult.Text = "Invalid Score";
                }
                else
                {
                    int y = CalculateNeededScore(x);
                    lblResult.Text = y + " Points To Reach 100";
                }
            }
            catch
            {
                lblResult.Text = "Enter a valid number";
            }
        }

        private void lblResult_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
