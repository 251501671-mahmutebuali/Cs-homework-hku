﻿namespace calc2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textScore = new TextBox();
            Enter = new Label();
            lblResult = new Label();
            btnCheckPass = new Button();
            btnLetterGrade = new Button();
            btnAverage = new Button();
            SuspendLayout();
            // 
            // textScore
            // 
            textScore.Location = new Point(44, 46);
            textScore.Name = "textScore";
            textScore.Size = new Size(230, 27);
            textScore.TabIndex = 0;
            textScore.TextChanged += textScore_TextChanged_1;
            // 
            // Enter
            // 
            Enter.AutoSize = true;
            Enter.Location = new Point(45, 17);
            Enter.Name = "Enter";
            Enter.Size = new Size(112, 20);
            Enter.TabIndex = 1;
            Enter.Text = "Enter The Score";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(363, 53);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(62, 25);
            lblResult.TabIndex = 2;
            lblResult.Text = ".................";
            lblResult.UseCompatibleTextRendering = true;
            lblResult.Click += lblResult_Click;
            // 
            // btnCheckPass
            // 
            btnCheckPass.Location = new Point(44, 89);
            btnCheckPass.Name = "btnCheckPass";
            btnCheckPass.Size = new Size(230, 29);
            btnCheckPass.TabIndex = 3;
            btnCheckPass.Text = "Pass or Fail";
            btnCheckPass.UseVisualStyleBackColor = true;
            btnCheckPass.Click += btnCheckPass_Click;
            // 
            // btnLetterGrade
            // 
            btnLetterGrade.Location = new Point(44, 124);
            btnLetterGrade.Name = "btnLetterGrade";
            btnLetterGrade.Size = new Size(230, 29);
            btnLetterGrade.TabIndex = 4;
            btnLetterGrade.Text = "Letter grade";
            btnLetterGrade.UseVisualStyleBackColor = true;
            btnLetterGrade.Click += btnLetterGrade_Click;
            // 
            // btnAverage
            // 
            btnAverage.Location = new Point(45, 159);
            btnAverage.Name = "btnAverage";
            btnAverage.Size = new Size(230, 29);
            btnAverage.TabIndex = 5;
            btnAverage.Text = "Average to 100";
            btnAverage.UseVisualStyleBackColor = true;
            btnAverage.Click += btnAverage_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAverage);
            Controls.Add(btnLetterGrade);
            Controls.Add(btnCheckPass);
            Controls.Add(lblResult);
            Controls.Add(Enter);
            Controls.Add(textScore);
            ForeColor = SystemColors.InfoText;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textScore;
        private Label Enter;
        private Label lblResult;
        private Button btnCheckPass;
        private Button btnLetterGrade;
        private Button btnAverage;
    }
}
